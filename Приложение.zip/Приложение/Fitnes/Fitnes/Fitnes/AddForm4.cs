﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class AddForm4 : Form
    {
        public AddForm4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 mainForm = this.Owner as Form9;
            if (mainForm == null)
            {
                MessageBox.Show("Ошибка: Главная форма недоступна");
                return;
            }

            try
            {
                // Проверка обязательных полей
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Поле 'Фамилия' обязательно для заполнения");
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Поле 'Имя' обязательно для заполнения");
                    textBox2.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Поле 'Телефон' обязательно для заполнения");
                    textBox4.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    MessageBox.Show("Поле 'Пароль' обязательно для заполнения");
                    textBox6.Focus();
                    return;
                }

                DataTable clientsTable = mainForm.фитнесDataSet1.Данные;
                DataRow newRow = clientsTable.NewRow();

                // Заполнение данных
                newRow["ID"] = textBox7.Text.Trim();
                newRow["Фамилия"] = textBox1.Text.Trim();
                newRow["Имя"] = textBox2.Text.Trim();
                newRow["Отчество"] = textBox3.Text.Trim();
                newRow["Телефон"] = textBox4.Text.Trim();
                newRow["Почта"] = textBox5.Text.Trim();
                newRow["Пароль"] = textBox6.Text.Trim();

                clientsTable.Rows.Add(newRow);

                // Сохраняем изменения
                mainForm.данныеTableAdapter.Update(mainForm.фитнесDataSet1.Данные);
                mainForm.данныеTableAdapter.Fill(mainForm.фитнесDataSet1.Данные);
                mainForm.dataGridView1.Refresh();

                ClearTextBoxes();
                MessageBox.Show("Данные успешно добавлен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\n{ex.StackTrace}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private DateTime ParseDateTime(string input)
        {

            throw new FormatException();
        }

        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }
    }
}
