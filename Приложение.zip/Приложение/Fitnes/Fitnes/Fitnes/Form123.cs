﻿using Fitnes.ФитнесDataSet1TableAdapters;
using System;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class Form123 : Form
    {
        public Form123()
        {
            InitializeComponent();
        }

        private void Form123_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "фитнесDataSet1.Тренировки". При необходимости она может быть перемещена или удалена.
            this.тренировкиTableAdapter.Fill(this.фитнесDataSet1.Тренировки);
            // Исправлено: заполняем именно таблицу Абонементы правильным адаптером
            this.тренировкиTableAdapter.Fill(this.фитнесDataSet1.Тренировки);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Исправлено: сохраняем изменения через правильный адаптер абонементов
            this.тренировкиTableAdapter.Update(this.фитнесDataSet1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddForm99 af = new AddForm99();
            af.Owner = this;
            af.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SearchForm5 sf = new SearchForm5();
            sf.Owner = this;
            sf.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
