﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 mainForm = this.Owner as Form6;
            if (mainForm == null)
            {
                MessageBox.Show("Ошибка: Главная форма недоступна");
                return;
            }

            try
            {
                // Проверка обязательных полей
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Поле 'Фамилия' обязательно для заполнения");
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Поле 'Имя' обязательно для заполнения");
                    textBox2.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Поле 'Телефон' обязательно для заполнения");
                    textBox4.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    MessageBox.Show("Поле 'Дата рождения' обязательно для заполнения");
                    textBox6.Focus();
                    return;
                }

                DataTable clientsTable = mainForm.фитнесDataSet1.Клиенты;
                DataRow newRow = clientsTable.NewRow();

                // Заполнение данных
                newRow["Код_Клиента"] = textBox7.Text.Trim();
                newRow["Фамилия"] = textBox1.Text.Trim();
                newRow["Имя"] = textBox2.Text.Trim();
                newRow["Отчество"] = textBox3.Text.Trim();
                newRow["Телефон"] = textBox4.Text.Trim();
                newRow["Почта"] = textBox5.Text.Trim();
                newRow["Дата_Рождения"] = ParseDateTime(textBox6.Text);

                clientsTable.Rows.Add(newRow);

                // Сохраняем изменения
                mainForm.клиентыTableAdapter.Update(mainForm.фитнесDataSet1.Клиенты);
                mainForm.клиентыTableAdapter.Fill(mainForm.фитнесDataSet1.Клиенты);
                mainForm.dataGridView1.Refresh();

                ClearTextBoxes();
                MessageBox.Show("Клиент успешно добавлен!");
            }
            catch (FormatException ex)
            {
                MessageBox.Show($"Ошибка формата даты: {ex.Message}\nПример: 31-12-2000",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
                textBox6.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\n{ex.StackTrace}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private DateTime ParseDateTime(string input)
        {
            if (DateTime.TryParseExact(input, "dd-MM-yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None,
                out DateTime result))
            {
                return result;
            }

            throw new FormatException();
        }

        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }

        private void AddForm_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}