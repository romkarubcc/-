﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Fitnes
{
    public partial class AddForm99 : Form
    {
        public AddForm99()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form123 mainForm = this.Owner as Form123;
            if (mainForm == null)
            {
                MessageBox.Show("Ошибка: Главная форма недоступна");
                return;
            }

            try
            {
                // Проверка обязательных полей
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Поле 'Код_Тренера' обязательно для заполнения");
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Поле 'Код_Клиента' обязательно для заполнения");
                    textBox2.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Поле 'Дата тренировки' обязательно для заполнения");
                    textBox4.Focus();
                    return;
                }


                DataTable clientsTable = mainForm.фитнесDataSet1.Тренировки;
                DataRow newRow = clientsTable.NewRow();

                // Заполнение данных
                newRow["Код_тренировок"] = textBox1.Text.Trim();
                newRow["Код_Тренера"] = textBox5.Text.Trim();
                newRow["Код_Клиента"] = textBox2.Text.Trim();
                newRow["Время тренировки"] = textBox3.Text.Trim();
                newRow["Дата тренировки"] = textBox4.Text.Trim();

                clientsTable.Rows.Add(newRow);

                // Сохраняем изменения
                mainForm.тренировкиTableAdapter.Update(mainForm.фитнесDataSet1.Тренировки);
                mainForm.тренировкиTableAdapter.Fill(mainForm.фитнесDataSet1.Тренировки);
                mainForm.dataGridView1.Refresh();

                ClearTextBoxes();
                MessageBox.Show("Тренировка успешно добавлена!");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\n{ex.StackTrace}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddForm99_Load(object sender, EventArgs e)
        {

        }
    }
}
