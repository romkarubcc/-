﻿using Fitnes.ФитнесDataSet1TableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "фитнесDataSet1.Абонименты". При необходимости она может быть перемещена или удалена.
            this.абонементыTableAdapter.Fill(this.фитнесDataSet1.Абонементы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            абонементыTableAdapter.Update(фитнесDataSet1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddForm2 af = new AddForm2();
            af.Owner = this;
            af.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SearchForm2 sf = new SearchForm2();
            sf.Owner = this;
            sf.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void абонементыBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
