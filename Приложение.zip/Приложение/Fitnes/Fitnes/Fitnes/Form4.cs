﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fitnes
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8 ne = new Form8();
            ne.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form9 ne = new Form9();
            ne.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 ne = new Form6(); 
            ne.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form7 ne = new Form7();
            ne.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form123 ne = new Form123();
            ne.Show();
        }
    }
}
