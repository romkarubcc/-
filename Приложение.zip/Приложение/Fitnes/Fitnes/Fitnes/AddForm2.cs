﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Fitnes
{
    public partial class AddForm2 : Form
    {
        public AddForm2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 mainForm = this.Owner as Form7;
            if (mainForm == null)
            {
                MessageBox.Show("Ошибка: Главная форма недоступна");
                return;
            }

            try
            {
                // Проверка обязательных полей
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Поле 'Название' обязательно для заполнения");
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Поле 'Стоимость' обязательно для заполнения");
                    textBox2.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Поле 'Срок действия' обязательно для заполнения");
                    textBox4.Focus();
                    return;
                }


                DataTable clientsTable = mainForm.фитнесDataSet1.Абонементы;
                DataRow newRow = clientsTable.NewRow();

                // Заполнение данных
                newRow["Код_Абонимента"] = textBox1.Text.Trim();
                newRow["Название"] = textBox2.Text.Trim();
                newRow["Стоимость"] = textBox3.Text.Trim();
                newRow["Срок_Действия"] = textBox4.Text.Trim();

                clientsTable.Rows.Add(newRow);

                // Сохраняем изменения
                mainForm.абонементыTableAdapter.Update(mainForm.фитнесDataSet1.Абонементы);
                mainForm.абонементыTableAdapter.Fill(mainForm.фитнесDataSet1.Абонементы);
                mainForm.dataGridView1.Refresh();

                ClearTextBoxes();
                MessageBox.Show("Клиент успешно добавлен!");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\n{ex.StackTrace}",
                              "Ошибка",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           Close();
        }
    }
}
