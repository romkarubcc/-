﻿
using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class RequestForm : Form
    {
        private readonly string email;
        private TextBox phone;
        private TextBox comment;
        private ComboBox service;

        public RequestForm(string userEmail)
        {
            email = userEmail;

            Text = "Заявка в фитнес-клуб";
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(480, 390);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            BackColor = Color.FromArgb(245, 248, 246);

            Controls.Add(new Label
            {
                Text = "Заявка на услугу",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(28, 100, 76),
                AutoSize = true,
                Location = new Point(95, 20)
            });

            Controls.Add(new Label
            {
                Text = "Ваша почта: " + email,
                Location = new Point(35, 70),
                AutoSize = true
            });

            Controls.Add(new Label
            {
                Text = "Интересующая услуга",
                Location = new Point(35, 105),
                AutoSize = true
            });

            service = new ComboBox
            {
                Location = new Point(35, 128),
                Width = 405,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            service.Items.AddRange(new object[]
            {
                "Покупка абонемента",
                "Персональная тренировка",
                "Консультация тренера",
                "Общая консультация"
            });

            service.SelectedIndex = 0;
            Controls.Add(service);

            Controls.Add(new Label
            {
                Text = "Телефон для связи",
                Location = new Point(35, 170),
                AutoSize = true
            });

            phone = new TextBox
            {
                Location = new Point(35, 193),
                Width = 405
            };
            Controls.Add(phone);

            Controls.Add(new Label
            {
                Text = "Комментарий",
                Location = new Point(35, 230),
                AutoSize = true
            });

            comment = new TextBox
            {
                Location = new Point(35, 253),
                Width = 405,
                Height = 45,
                Multiline = true
            };
            Controls.Add(comment);

            var send = new Button
            {
                Text = "Отправить заявку",
                Location = new Point(35, 320),
                Size = new Size(190, 38),
                BackColor = Color.FromArgb(28, 100, 76),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            send.Click += SendClick;
            Controls.Add(send);

            var cancel = new Button
            {
                Text = "Отмена",
                Location = new Point(270, 320),
                Size = new Size(170, 38)
            };

            cancel.Click += (s, e) => Close();
            Controls.Add(cancel);

            AcceptButton = send;
            CancelButton = cancel;
        }

        private void SendClick(object sender, EventArgs e)
        {
            string phoneValue = phone.Text.Trim();
            string commentValue = comment.Text.Trim();

            if (string.IsNullOrWhiteSpace(phoneValue))
            {
                MessageBox.Show("Укажите телефон для связи.");
                return;
            }

            try
            {
                using (var cn = Database.Connection())
                {
                    cn.Open();

                    using (var cmd = new OleDbCommand(
                        "INSERT INTO [Заявки] " +
                        "([Почта], [Услуга], [Телефон], " +
                        "[Комментарий], [ДатаЗаявки], [Статус]) " +
                        "VALUES (?, ?, ?, ?, ?, ?)", cn))
                    {
                        // Порядок параметров должен совпадать
                        // с порядком знаков вопроса в запросе.
                        cmd.Parameters.Add(
                            "p1", OleDbType.VarWChar, 255).Value = email;

                        cmd.Parameters.Add(
                            "p2", OleDbType.VarWChar, 255).Value =
                            service.SelectedItem.ToString();

                        cmd.Parameters.Add(
                            "p3", OleDbType.VarWChar, 50).Value =
                            phoneValue;

                        cmd.Parameters.Add(
                            "p4", OleDbType.LongVarWChar).Value =
                            commentValue;

                        cmd.Parameters.Add(
                            "p5", OleDbType.Date).Value = DateTime.Now;

                        cmd.Parameters.Add(
                            "p6", OleDbType.VarWChar, 50).Value = "Новая";

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show(
                                "Заявка успешно отправлена!",
                                "Фитнес-клуб",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
                            );

                            Close();
                        }
                        else
                        {
                            MessageBox.Show(
                                "Заявка не была добавлена. Попробуйте ещё раз."
                            );
                        }
                    }
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show(
                    "Access не смог сохранить заявку.\n\n" +
                    "Возможно, тип одного из полей таблицы «Заявки» " +
                    "не совпадает с типом передаваемого значения.\n\n" +
                    "Подробности: " + ex.Message,
                    "Ошибка сохранения",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось сохранить заявку.\n\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
