﻿using System;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class AdminLoginForm : Form
    {
        TextBox emailBox, passwordBox;
        public AdminLoginForm()
        {
            Text = "Вход администратора"; StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(410, 290); FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
            BackColor = Color.FromArgb(245,248,246);
            Controls.Add(new Label { Text = "Вход администратора", Font = new Font("Segoe UI", 18, FontStyle.Bold), ForeColor = Color.FromArgb(28,100,76), AutoSize = true, Location = new Point(62,25) });
            Controls.Add(new Label { Text = "Почта администратора", Location = new Point(40,85), AutoSize = true });
            emailBox = new TextBox { Location = new Point(40,108), Width = 330, Font = new Font("Segoe UI", 11) }; Controls.Add(emailBox);
            Controls.Add(new Label { Text = "Пароль", Location = new Point(40,148), AutoSize = true });
            passwordBox = new TextBox { Location = new Point(40,171), Width = 330, UseSystemPasswordChar = true, Font = new Font("Segoe UI", 11) }; Controls.Add(passwordBox);
            var login = new Button { Text = "Войти", Location = new Point(40,220), Size = new Size(150,36), BackColor = Color.FromArgb(28,100,76), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            login.Click += LoginClick; Controls.Add(login);
            var cancel = new Button { Text = "Назад", Location = new Point(220,220), Size = new Size(150,36) }; cancel.Click += (s,e) => Close(); Controls.Add(cancel);
            AcceptButton = login;
        }
        private void LoginClick(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(emailBox.Text) || string.IsNullOrWhiteSpace(passwordBox.Text))
            { MessageBox.Show("Введите почту и пароль."); return; }
            try
            {
                // В текущей базе администратор обозначен записью с Фамилия=admin и Имя=admin.
                using (var cn = Database.Connection())
                using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Данные] WHERE [Почта]=? AND [Пароль]=? AND [Фамилия]='admin' AND [Имя]='admin'", cn))
                {
                    cmd.Parameters.AddWithValue("@p1", emailBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@p2", passwordBox.Text);
                    cn.Open();
                    if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                    {
                        Hide();
                        using (var admin = new Form4()) admin.ShowDialog();
                        Close();
                    }
                    else MessageBox.Show("Данные администратора не найдены. Проверьте почту и пароль.", "Вход не выполнен", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка подключения к Фитнес.accdb.\n\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
