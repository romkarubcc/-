﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class UserHomeForm : Form
    {
        private readonly string email;
        public UserHomeForm(string userEmail)
        {
            email = userEmail;
            Text = "Фитнес-клуб | Личный кабинет"; StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(700, 460); BackColor = Color.FromArgb(245,248,246);
            Controls.Add(new Label { Text = "Добро пожаловать в FITNESS CLUB", Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = Color.FromArgb(28,100,76), AutoSize = true, Location = new Point(45, 30) });
            Controls.Add(new Label { Text = "Аккаунт: " + email, Font = new Font("Segoe UI", 10), AutoSize = true, Location = new Point(48, 80) });
            var panel = new Panel { Location = new Point(45, 125), Size = new Size(610, 190), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            panel.Controls.Add(new Label { Text = "Тренируйся. Развивайся. Достигай.", Font = new Font("Segoe UI", 16, FontStyle.Bold), ForeColor = Color.FromArgb(28,100,76), AutoSize = true, Location = new Point(25, 25) });
            panel.Controls.Add(new Label { Text = "Оставьте заявку, и администратор поможет подобрать услугу.", Font = new Font("Segoe UI", 10), AutoSize = true, Location = new Point(27, 72) });
            var request = new Button { Text = "Оставить заявку", Location = new Point(27, 115), Size = new Size(190, 42), BackColor = Color.FromArgb(28,100,76), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            request.Click += (s,e) => { using (var f = new RequestForm(email)) f.ShowDialog(this); };
            panel.Controls.Add(request); Controls.Add(panel);
            var logout = new Button { Text = "Выйти из аккаунта", Location = new Point(500, 375), Size = new Size(155, 36), FlatStyle = FlatStyle.Flat };
            logout.Click += (s,e) => Close(); Controls.Add(logout);
        }
    }
}
