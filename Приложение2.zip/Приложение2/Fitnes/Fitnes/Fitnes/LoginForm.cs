﻿
using System;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class LoginForm : Form
    {
        private TextBox emailBox;
        private TextBox passwordBox;

        public LoginForm()
        {
            Text = "Фитнес-клуб | Вход";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(420, 330);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            BackColor = Color.FromArgb(245, 248, 246);

            var title = new Label
            {
                Text = "FITNESS CLUB",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.FromArgb(28, 100, 76),
                AutoSize = true,
                Location = new Point(94, 28)
            };
            Controls.Add(title);

            Controls.Add(new Label
            {
                Text = "Войдите в аккаунт или зарегистрируйтесь",
                Font = new Font("Segoe UI", 9),
                AutoSize = true,
                Location = new Point(70, 72)
            });

            Controls.Add(new Label
            {
                Text = "Электронная почта",
                Location = new Point(45, 118),
                AutoSize = true
            });

            emailBox = new TextBox
            {
                Location = new Point(45, 140),
                Width = 330,
                Font = new Font("Segoe UI", 11)
            };
            Controls.Add(emailBox);

            Controls.Add(new Label
            {
                Text = "Пароль",
                Location = new Point(45, 181),
                AutoSize = true
            });

            passwordBox = new TextBox
            {
                Location = new Point(45, 203),
                Width = 330,
                UseSystemPasswordChar = true,
                Font = new Font("Segoe UI", 11)
            };
            Controls.Add(passwordBox);

            var login = new Button
            {
                Text = "Войти",
                Location = new Point(45, 252),
                Size = new Size(155, 38),
                BackColor = Color.FromArgb(28, 100, 76),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            login.Click += LoginClick;

            var register = new Button
            {
                Text = "Регистрация",
                Location = new Point(220, 252),
                Size = new Size(155, 38),
                FlatStyle = FlatStyle.Flat
            };

            register.Click += (s, e) =>
            {
                using (var form = new RegisterForm())
                {
                    form.ShowDialog(this);
                }
            };

            Controls.Add(login);
            Controls.Add(register);

            AcceptButton = login;
        }

        private void LoginClick(object sender, EventArgs e)
        {
            string email = emailBox.Text.Trim();
            string password = passwordBox.Text;

            if (string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите почту и пароль.");
                return;
            }

            try
            {
                bool authorized = false;

                using (var cn = Database.Connection())
                {
                    cn.Open();

                    string sql =
                        "SELECT [Почта], [Пароль] FROM [Данные]";

                    using (var cmd = new OleDbCommand(sql, cn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string savedEmail = reader.IsDBNull(0)
                                ? ""
                                : Convert.ToString(reader.GetValue(0)).Trim();

                            string savedPassword = reader.IsDBNull(1)
                                ? ""
                                : Convert.ToString(reader.GetValue(1));

                            bool emailMatches = string.Equals(
                                savedEmail,
                                email,
                                StringComparison.OrdinalIgnoreCase
                            );

                            bool passwordMatches = string.Equals(
                                savedPassword,
                                password,
                                StringComparison.Ordinal
                            );

                            if (emailMatches && passwordMatches)
                            {
                                authorized = true;
                                break;
                            }
                        }
                    }
                }

                if (!authorized)
                {
                    MessageBox.Show(
                        "Пользователь не найден или пароль не совпадает.\n\n" +
                        "Проверьте почту и пароль в таблице «Данные» " +
                        "файла Фитнес.accdb.",
                        "Вход не выполнен",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                Hide();

                try
                {
                    using (var form = new UserHomeForm(email))
                    {
                        form.ShowDialog(this);
                    }
                }
                finally
                {
                    Show();
                    passwordBox.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ошибка при входе в приложение.\n\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
