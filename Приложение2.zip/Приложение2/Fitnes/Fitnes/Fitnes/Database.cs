﻿using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace Fitnes
{
    internal static class Database
    {
        public static OleDbConnection Connection()
        {
            string path = Path.Combine(Application.StartupPath, "Фитнес.accdb");
            if (!File.Exists(path))
                throw new FileNotFoundException("Не найдена база данных: " + path + ". Скопируйте Фитнес.accdb в папку запуска приложения.");
            return new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Persist Security Info=False;");
        }
    }
}
