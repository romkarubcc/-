﻿using System;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class RegisterForm : Form
    {
        TextBox surname, firstName, patronymic, phone, email, password;

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // RegisterForm
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "RegisterForm";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.ResumeLayout(false);

        }

        public RegisterForm()
        {
            Text = "Регистрация"; StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(420, 470); FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
            BackColor = Color.FromArgb(245, 248, 246);
            Controls.Add(new Label { Text = "Создание аккаунта", Font = new Font("Segoe UI", 18, FontStyle.Bold), ForeColor = Color.FromArgb(28,100,76), AutoSize = true, Location = new Point(82, 18) });
            int y = 65;
            surname = AddField("Фамилия *", ref y); firstName = AddField("Имя *", ref y);
            patronymic = AddField("Отчество", ref y); phone = AddField("Телефон *", ref y);
            email = AddField("Электронная почта *", ref y); password = AddField("Пароль *", ref y);
            password.UseSystemPasswordChar = true;
            var save = new Button { Text = "Зарегистрироваться", Location = new Point(85, 415), Size = new Size(250, 38), BackColor = Color.FromArgb(28,100,76), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            save.Click += SaveClick; Controls.Add(save); AcceptButton = save;
        }
        private TextBox AddField(string label, ref int y)
        {
            Controls.Add(new Label { Text = label, Location = new Point(45,y), AutoSize = true });
            var t = new TextBox { Location = new Point(45,y+19), Width = 330, Font = new Font("Segoe UI", 10) };
            Controls.Add(t); y += 55; return t;
        }
        private void SaveClick(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(surname.Text) || string.IsNullOrWhiteSpace(firstName.Text) ||
                string.IsNullOrWhiteSpace(phone.Text) || string.IsNullOrWhiteSpace(email.Text) || string.IsNullOrWhiteSpace(password.Text))
            { MessageBox.Show("Заполните все обязательные поля, отмеченные звёздочкой."); return; }
            if (password.Text.Length < 4) { MessageBox.Show("Пароль должен содержать минимум 4 символа."); return; }
            try
            {
                using (var cn = Database.Connection())
                {
                    cn.Open();
                    using (var check = new OleDbCommand("SELECT COUNT(*) FROM [Данные] WHERE [Почта]=?", cn))
                    {
                        check.Parameters.AddWithValue("@p1", email.Text.Trim());
                        if (Convert.ToInt32(check.ExecuteScalar()) > 0) { MessageBox.Show("Аккаунт с такой почтой уже существует."); return; }
                    }
                    using (var cmd = new OleDbCommand("INSERT INTO [Данные] ([Фамилия],[Имя],[Отчество],[Телефон],[Почта],[Пароль]) VALUES (?,?,?,?,?,?)", cn))
                    {
                        cmd.Parameters.AddWithValue("@p1", surname.Text.Trim());
                        cmd.Parameters.AddWithValue("@p2", firstName.Text.Trim());
                        cmd.Parameters.AddWithValue("@p3", patronymic.Text.Trim());
                        cmd.Parameters.AddWithValue("@p4", phone.Text.Trim());
                        cmd.Parameters.AddWithValue("@p5", email.Text.Trim());
                        cmd.Parameters.AddWithValue("@p6", password.Text);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Регистрация прошла успешно! Теперь можно войти.");
                Close();
            }
            catch (Exception ex) { MessageBox.Show("Ошибка регистрации. Проверьте поля таблицы Данные в базе Фитнес.accdb.\n\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
