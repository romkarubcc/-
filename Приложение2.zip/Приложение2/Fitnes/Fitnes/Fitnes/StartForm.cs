﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Fitnes
{
    public class StartForm : Form
    {
        public StartForm()
        {
            Text = "FITNESS CLUB | Добро пожаловать";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(520, 360);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            BackColor = Color.FromArgb(245, 248, 246);

            Controls.Add(new Label {
                Text = "FITNESS CLUB", Font = new Font("Segoe UI", 25, FontStyle.Bold),
                ForeColor = Color.FromArgb(28, 100, 76), AutoSize = true, Location = new Point(112, 36)
            });
            Controls.Add(new Label {
                Text = "Тренируйся. Развивайся. Достигай.",
                Font = new Font("Segoe UI", 11), AutoSize = true, Location = new Point(115, 82)
            });
            var user = new Button {
                Text = "Вход для пользователя", Location = new Point(95, 145), Size = new Size(330, 48),
                Font = new Font("Segoe UI", 11, FontStyle.Bold), BackColor = Color.FromArgb(28, 100, 76),
                ForeColor = Color.White, FlatStyle = FlatStyle.Flat
            };
            user.Click += (s, e) => { using (var f = new LoginForm()) f.ShowDialog(this); };
            var admin = new Button {
                Text = "Вход для администратора", Location = new Point(95, 207), Size = new Size(330, 48),
                Font = new Font("Segoe UI", 11), FlatStyle = FlatStyle.Flat
            };
            admin.Click += (s, e) => { using (var f = new AdminLoginForm()) f.ShowDialog(this); };
            Controls.Add(user); Controls.Add(admin);
            Controls.Add(new Label { Text = "Фитнес-клуб · Личный кабинет и услуги", ForeColor = Color.Gray, AutoSize = true, Location = new Point(130, 300) });
        }
    }
}
